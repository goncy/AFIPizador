/* window.navigate = function(x) { window.location.href = x;} 
if (document.form1) form1 = document.form1; */