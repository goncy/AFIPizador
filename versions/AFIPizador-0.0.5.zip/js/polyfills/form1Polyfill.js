// Replace form1 por document.form1
if (document.form1) form1 = document.form1;